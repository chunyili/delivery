require 'test_helper'

class CarryTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
