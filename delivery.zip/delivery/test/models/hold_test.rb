require 'test_helper'

class HoldTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
