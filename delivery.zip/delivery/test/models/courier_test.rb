require 'test_helper'

class CourierTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
