require 'test_helper'

class CustomerAddTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
