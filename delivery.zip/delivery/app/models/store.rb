class Store < ActiveRecord::Base
end
