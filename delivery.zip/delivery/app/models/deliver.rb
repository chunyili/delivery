class Deliver < ActiveRecord::Base
end
