class StoreAdd < ActiveRecord::Base
end
