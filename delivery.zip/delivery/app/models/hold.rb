class Hold < ActiveRecord::Base
  self.primary_key = :pkg_id
end
