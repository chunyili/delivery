class CustomerAdd < ActiveRecord::Base
  belongs_to :Customer
end
