class Route < ActiveRecord::Base

  has_many :instances, class_name: "Instance", foreign_key: "route_id"
end
