class Courier < ActiveRecord::Base
  self.primary_key = :courier_id
end
